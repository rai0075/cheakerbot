from aiogram import Router, types, Bot
from aiogram.filters import Command
from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton, CallbackQuery
from config import FORCE_CHANNEL, FORCE_GROUP, CHANNEL_LINK, GROUP_LINK, WELCOME_MSG, LOG_CHANNEL_ID

router = Router()

# Start command
@router.message(Command("start"))
async def start_command(message: types.Message):
    full_name = message.from_user.full_name

    keyboard = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="📢 Join Channel", url=CHANNEL_LINK)],
        [InlineKeyboardButton(text="👥 Join Group", url=GROUP_LINK)],
        [InlineKeyboardButton(text="✅ I've Joined", callback_data="check_joined")]
    ])

    await message.answer(
        f"👋 Welcome {full_name}!\n\n{WELCOME_MSG}",
        reply_markup=keyboard
    )

# Callback for "I've Joined"
@router.callback_query(lambda c: c.data == "check_joined")
async def check_joined(callback: CallbackQuery, bot: Bot):
    user_id = callback.from_user.id
    full_name = callback.from_user.full_name
    username = f"@{callback.from_user.username}" if callback.from_user.username else "No Username"

    try:
        # Check membership in channel & group
        channel_member = await bot.get_chat_member(FORCE_CHANNEL, user_id)
        group_member = await bot.get_chat_member(FORCE_GROUP, user_id)

        if (channel_member.status in ["member", "administrator", "creator"]) and \
           (group_member.status in ["member", "administrator", "creator"]):

            # ✅ Show success with Exonary ID to user
            await callback.message.edit_text(
                f"✅ You have successfully joined both Channel & Group.\n\n"
                f"🔹 Your Exonary ID: {user_id}\n"
                f"THANKS FOR CONNECT WITH EXONARY LAB 🎉"
            )

            # 🔒 Log user details to private channel
            log_text = (
                f"🆕 New Verified User\n\n"
                f"👤 Name: {full_name}\n"
                f"🔹 Username: {username}\n"
                f"🆔 Exonary ID: <code>{user_id}</code>"
            )
            await bot.send_message(LOG_CHANNEL_ID, log_text)

        else:
            await callback.answer("⚠️ You must join both Channel & Group first!", show_alert=True)

    except Exception as e:
        await callback.message.answer(f"❌ Error while checking membership: {e}")

BOT_TOKEN = "8467318754:AAGWmVpIBDykLHlmsri_TrWa_hOWJmav8IA"

# Force join settings
FORCE_CHANNEL = -1002701779557   # channel id
FORCE_GROUP   = -1002947361915   # group id

# Private log channel ID
LOG_CHANNEL_ID = -1003098947054  # <-- Replace with your private log channel ID

# Invite links
CHANNEL_LINK = "https://t.me/Exonarylab"
GROUP_LINK   = "https://t.me/+ujpAaRxpD_FmNDQ1"

# Messages
WELCOME_MSG = "👋 Welcome to Exonary Checker Bot!"
HELP_MSG = (
    "🤖 Exonary Checker Bot Commands:\n\n"
    "/start - Start the bot and verify access\n"
    "/help - Show this help message\n\n"
    "⚠️ You must join our channel and group first to use this bot."
)

ALERT_MESSAGE = "⏰ Daily Reminder: Stay active with Exonary Checker Bot!"

import logging
import asyncio
from aiogram import Bot, Dispatcher
from aiogram.enums import ParseMode
from aiogram.client.default import DefaultBotProperties

from config import BOT_TOKEN
from bot_handlers import routers

# Logging
logging.basicConfig(level=logging.INFO)

# ✅ Correct way for aiogram 3.22.0
bot = Bot(
    token=BOT_TOKEN,
    default=DefaultBotProperties(parse_mode=ParseMode.MARKDOWN)
)

dp = Dispatcher()

# Include all routers
for router in routers:
    dp.include_router(router)

# Run bot
async def main():
    print("🚀 Bot is starting...")
    await dp.start_polling(bot)

if __name__ == "__main__":
    asyncio.run(main())
